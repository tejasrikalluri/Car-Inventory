package com.carinventory.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import com.carinventory.model.CarInventory;

public class CarInventoryDao {
	@Autowired
	JdbcTemplate jdbcTemplate;

	public int save(CarInventory e) {
		String query = "insert into carInventoryData values('" + e.getModelNum() + "'," + e.getPrice() + ",'"
				+ e.getMake() + "'," + e.getYear() + ")";
		return jdbcTemplate.update(query);
	}

	public List<CarInventory> fetchCarInfo() {
		return jdbcTemplate.query("select * from carInventoryData", new RowMapper<CarInventory>() {
			public CarInventory mapRow(ResultSet rs, int rownumber) throws SQLException {
				CarInventory e = new CarInventory();
				e.setMake(rs.getString("make"));
				e.setModelNum(rs.getString("modelNum"));
				e.setPrice(rs.getFloat("price"));
				e.setYear(rs.getLong("year"));
				return e;
			}

		});

	}

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
}
