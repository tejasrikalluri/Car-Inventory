package com.carinventory.main;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.carinventory.dao.CarInventoryDao;
import com.carinventory.model.CarInventory;

public class App {
	public static void main(String[] args) {
		System.out.println("Welcome to Tejasri Car Inventory!");
		ApplicationContext con = new ClassPathXmlApplicationContext("bean.xml");
		CarInventoryDao dao = con.getBean("carInventoryDao", CarInventoryDao.class);
		CarInventory car = new CarInventory();
		readInput(car, dao);
	}

	private static void saveData(String str, CarInventory car, CarInventoryDao doa) {
		Scanner sc1 = new Scanner(System.in);
		System.out.println("Make:");
		String make = sc1.nextLine();
		car.setMake(make);
		System.out.println("Model:");
		String model = sc1.nextLine();
		car.setModelNum(model);
		System.out.println("Year:");
		long year = sc1.nextLong();
		car.setYear(year);
		System.out.println("Sales Price ($):");
		float price = sc1.nextFloat();
		car.setPrice(price);
		doa.save(car);
		readInput(car, doa);
	}

	private static void showData(CarInventory car, CarInventoryDao doa) {
		List<CarInventory> list = doa.fetchCarInfo();
		list.forEach(carIn -> System.out.println(
				carIn.getYear() + " " + carIn.getMake() + " " + carIn.getModelNum() + " $" + carIn.getPrice()));
		if (list.size() == 0) {
			System.out.println("There are currently no cars in the catalog");
		} else {
			System.out.println("Number of cars: " + list.size());
			double total = list.stream().mapToDouble(x -> x.getPrice()).sum();
			String strDouble = String.format("%.2f", total);
			System.out.println("Total Inventory: $" + strDouble);
		}
		readInput(car, doa);
	}

	public static String checkInput(String cmd, CarInventory car, CarInventoryDao doa) {
		if (cmd.equals("add")) {
			saveData(cmd, car, doa);
		} else if (cmd.equals("list")) {
			showData(car, doa);
		} else if (cmd.equals("quit")) {
			System.out.println("Good bye!");
		} else {
			System.out.println("Sorry, but '" + cmd + "' is not a valid command. Please try again");
			readInput(car, doa);
		}
		return null;
	}

	public static void readInput(CarInventory car, CarInventoryDao doa) {
		Scanner sc1 = new Scanner(System.in);
		System.out.println("Enter Command:");
		String cmd = sc1.nextLine();
		checkInput(cmd, car, doa);
	}

}
